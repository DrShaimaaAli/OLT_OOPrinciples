
public class Account implements IAccount{

	final static String[] ACCOUNT_TYPES = {"Debit", "Credit", "Saving"};
	   private long accountNumber;
	   private double accountBalance;
	   private String accountType;
	   
	   AccessAccount access = new AccessAccount();
	   Account(){}
	   Account(AccessAccount access)
	   {
		   this.access = access;
	   }
	   
	   /**
	     * @return the accountUserName
	     */
	    public String getAccountUserName() {
	        return access.getAccountUserName();
	    }

	    /**
	     * @param accountUserName the accountUserName to set
	     */
	    public void setAccountUserName(String accountUserName) {
	    	access.setAccountUserName(accountUserName);
	    }

	    public String getAccountPassword() {
	        return access.getAccountPassword();
	    }
	    public void setAccountPassword(String accountPassword) {
	    	access.setAccountPassword(accountPassword);
	    }
	   
	   /**
	     * @return the accountNumber
	     */
	    public long getAccountNumber() {
	        return accountNumber;
	    }

	    /**
	     * @param accountNumber the accountNumber to set
	     */
	    public void setAccountNumber(long accountNumber) {
	        this.accountNumber = accountNumber;
	    }

	   
	    /**
	     * @return the accountBalance
	     */
	    public double getAccountBalance() {
	        return accountBalance;
	    }

	    /**
	     * @param accountBalance the accountBalance to set
	     */
	    public void setAccountBalance(double accountBalance) {
	        this.accountBalance = accountBalance;
	    }

	    /**
	     * @return the accountType
	     */
	    public String getAccountType() {
	        return accountType;
	    }

	    /**
	     * @param accountType the accountType to set
	     */
	    public void setAccountType(String accountType) {
	        this.accountType = accountType;
	    }
	    
	    public void deposit()
	    {
	    }
	    
	    public void withdraw()
	    {}
}
