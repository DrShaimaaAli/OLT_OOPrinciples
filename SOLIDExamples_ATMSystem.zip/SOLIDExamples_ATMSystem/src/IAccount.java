
public interface IAccount {

	public double getAccountBalance();
 
    public void setAccountBalance(double accountBalance);
}
