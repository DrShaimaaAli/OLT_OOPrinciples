
public class ATM {

	 final static String[] ATM_OPTIONS = {"login","choose acct type","deposit","withdraw","exit"};
	 IAccount account;
	 
	 ATM(IAccount account)
	 {
		 this.account = account;
	 }
	 
	 public void login()
	 {}

	 public void depoist(double newAmount)
	 {
		 account.setAccountBalance(account.getAccountBalance() + newAmount);
         System.out.println("New balance is:" + account.getAccountBalance());
	 }
	 
	 public void withdraw(double amount)
	 {
		 
		 // make sure there's enough balance before withdrawal
        double currentBalance = account.getAccountBalance();
         double balanceAfterWithdraw = currentBalance - amount;
         if ( balanceAfterWithdraw > 0 )
         {
         	account.setAccountBalance(balanceAfterWithdraw);
           System.out.println("New balance is:" + account.getAccountBalance());
         }
         else
             System.out.println("Balance is not sufficient");
	 }
}
