
public class SavingAccount extends Account {

	SavingAccount(){}
	SavingAccount(AccessAccount access){
		super(access);
	}
	public void deposit()
    {
	 // deposit logic for Saving account
    }
    
    public void withdraw()
    {
    	// withdrawal logic for the Saving account
    }
}
