import java.util.Scanner;
public class ATMSystem {
   
   
    final static String[] ATM_OPTIONS = {"login","choose acct type","deposit","withdraw","exit"};
    

   public static int printOptions(String[] options)
   {
	  
	   for (int i=0; i<options.length; i++)
           System.out.println(i +" - " + options[i]);
	   Scanner sc = new Scanner (System.in);
       int option = sc.nextInt();
	   return option;
   }
    
public static void main(String[] args) {
        
        Account account = new Account();
        ATM atm;
         //Display available options
        boolean runFlag = true;
        while (runFlag)
        {
	         System.out.println("Please choose the option number:");

	         
	         Scanner sc = new Scanner (System.in);
	         int option = printOptions(ATMSystem.ATM_OPTIONS);//sc.nextInt();
	         AccessAccount access = new AccessAccount();
	         switch(option)
	         {
	         	case 0:
		         
		             System.out.println("Please enter user name:\n");
		             String userName = sc.next();  
		    
		             
		             System.out.println("Please enter password:\n");
		             String password = sc.next();
		             
		             access = new AccessAccount(userName,password );
		             break;
	         	case 1: 
	         		 System.out.println("Please choose an account type:");
	   	        
			         int acct_option = printOptions(Account.ACCOUNT_TYPES);//sc.nextInt();
			         
			         account.setAccountType(Account.ACCOUNT_TYPES[acct_option]);
			         if (Account.ACCOUNT_TYPES[acct_option] == "Debt")
			        	 account = new DebtAccount(access);
			         else if (Account.ACCOUNT_TYPES[acct_option] == "Credit")
			        	 account = new CreditAccount(access);
			         else
			        	 account = new SavingAccount(access);
			         atm = new ATM(account);
			         System.out.println("Account type is set to:" + account.getAccountType());
			         break;
	         	case 2:
	         		
	                 System.out.println("Please enter amount to deposit");
	                 double newAmount = sc.nextDouble();
	                 atm.depoist(newAmount);
	                 
		             break;
	         	case 3:
                     System.out.println("Please enter amount to withdraw:");
                    double amount = sc.nextDouble();
                    atm.withdraw(amount);
                    
                   
                    break;
                 
	         	default:
	         		System.out.println("Goodbye");
	         		runFlag = false;
	             
	         }
        }
        
    }
    
}