
public class DebtAccount extends Account {

	DebtAccount(){}
	DebtAccount(AccessAccount access){
		super(access);
	}
	public void deposit()
    {
	 // deposit logic for debt account
    }
    
    public void withdraw()
    {
    	// withdrawal logic for the debt account
    }
}
