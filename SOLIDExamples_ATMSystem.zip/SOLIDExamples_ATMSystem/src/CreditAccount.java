
public class CreditAccount extends Account{

	CreditAccount(){}
	CreditAccount(AccessAccount access){
		super(access);
	}
	 public void deposit()
	    {
		 // deposit logic for credit account
	    }
	    
	    public void withdraw()
	    {
	    	// withdrawal logic for the credit account
	    }
}
