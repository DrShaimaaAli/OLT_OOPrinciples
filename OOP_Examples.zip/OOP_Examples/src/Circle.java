
public class Circle extends Shape  {

	private double radius;

	double getRadius() {
		return radius;
	}

	void setRadius(double radius) {
		this.radius = radius;
	}
	
	public void calcArea()
	{
		System.out.println("Calculating the area of a Circle");
	}
	
	public void draw()
	{
		System.out.println("Drawing a Circle");
	}
	
}
