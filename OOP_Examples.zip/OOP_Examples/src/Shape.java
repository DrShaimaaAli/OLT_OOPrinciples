
public abstract class Shape implements Drawable {
	private int x;
	private int y;
	
	int getX() {
		return x;
	}
	void setX(int x) {
		this.x = x;
	}
	int getY() {
		return y;
	}
	void setY(int y) {
		this.y = y;
	}
	
	abstract public void calcArea();
	
	
}
