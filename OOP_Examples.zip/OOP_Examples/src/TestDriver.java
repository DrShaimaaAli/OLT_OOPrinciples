
public class TestDriver {
	
	public static void drawSomething(Drawable d)
	{
		d.draw();
	}
	
	public static void main(String[] args) {
		//Shape s = new Shape();
		//s.setX(10);
		//s.setY(20);
		
		//System.out.println("Shape "+ s + " at:" + s.getX() + "," + s.getY() );
		
		Circle c = new Circle();
		c.setX(5);
		c.setY(9);
		
		System.out.println("Cirle "+ c + " at:" + c.getX() + "," + c.getY() );
		
		Rectangle r = new Rectangle();
		r.setX(5);
		r.setY(9);
		System.out.println("Rectangle "+ r + " at:" + r.getX() + "," + r.getY() );
		
		
		Shape[] shapsAr = new Shape[2];
		//shapsAr[0] = s;
		shapsAr[0] = c;
		shapsAr[1] = r;
		
		System.out.println("===========================================================");
		for (int i=0; i<shapsAr.length ; i++)
		{
			System.out.println("Shape "+ shapsAr[i] + " at:" + shapsAr[i].getX() + "," + shapsAr[i].getY() );
			shapsAr[i].calcArea();
			drawSomething(shapsAr[i]);
		}
		
		System.out.println("===========================================================");
		
		drawSomething(c);
		drawSomething(r);
		
		/*
		Employee e1 = new Employee();
		e1.setName("Alice");
		e1.setSalary(1000);
		
		Employee e2= new Employee();
		e2.setName("Bob");
		e2.setSalary(1500);
		
		System.out.println(e1.getName() + "--" + e2.getName());
		System.out.println(e1 + " -- " + e2);*/
	}
	
}
