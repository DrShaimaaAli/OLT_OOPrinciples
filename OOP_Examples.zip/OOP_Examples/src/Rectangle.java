
public class Rectangle extends Shape {
	private double length;
	private double width;
	double getLength() {
		return length;
	}
	void setLength(double length) {
		this.length = length;
	}
	double getWidth() {
		return width;
	}
	void setWidth(double width) {
		this.width = width;
	}
	
	public void calcArea()
	{
		System.out.println("Calculating the area of a Rectrangle");
	}
	
	public void draw()
	{
		System.out.println("Drawing a Rectangle");
	}

}
